import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { BocinaPage } from './bocina';

@NgModule({
  declarations: [
    BocinaPage,
  ],
  imports: [
    IonicPageModule.forChild(BocinaPage),
  ],
})
export class BocinaPageModule {}
